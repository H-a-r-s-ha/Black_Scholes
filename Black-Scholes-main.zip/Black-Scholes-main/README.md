install dependencies :- pip install streamlit numpy pandas matplotlib seaborn scipy scikit-learn joblib 




to run the project :- streamlit run Main.py
